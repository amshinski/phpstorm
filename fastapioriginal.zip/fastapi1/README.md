1. Перейти в корень проекта
2. py -m venv venv
3. source venv/Scripts/activate
4. pip install -r requirements.txt
5. py -m pip install --upgrade pip
6. cp .env.example .env
7. Секреты можно сгенерить командой py -m app.cli generate-secret
8. Создать БД в PgAdmin
9. Заполнить .env
10. alembic upgrade head
11. fastapi dev main.py
12. В браузере открыть 127.0.0.1:8000/docs

+ В PyCharm открыть requirements.txt и установить пакеты, если он ругается