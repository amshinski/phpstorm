from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import (DateTime, Index, String, text, UniqueConstraint)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database.db import BaseUUID
from app.core.database.mixins import TimestampMixin

if TYPE_CHECKING:
    from app.auth.models import RefreshToken, SMSCode


class User(BaseUUID, TimestampMixin):
    __tablename__ = "users"

    name: Mapped[str] = mapped_column(String(64), nullable=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    password: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[str] = mapped_column(String(64), nullable=True)

    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    refresh_tokens: Mapped[list["RefreshToken"]] = relationship(
        "RefreshToken", back_populates="user", passive_deletes=True, cascade="all, delete-orphan"
    )

    sms_codes: Mapped[list["SMSCode"]] = relationship(
        "SMSCode", back_populates="user", passive_deletes=True, cascade="all, delete-orphan"
    )

    __table_args__ = (
        UniqueConstraint("email", name="uq_users_email"),
        Index(
            "ix_users_email_active",
            "email",
            unique=True,
            postgresql_where=text("deleted_at IS NULL"),
        ),
    )
