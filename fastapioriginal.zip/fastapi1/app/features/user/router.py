from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database.db import get_db
from app.features.user import services
from app.features.user.dependencies import get_current_user
from app.features.user.models import User
from app.features.user.schemas import (CreateUserRequest, CreateUserResponse, UserRead)

router = APIRouter(prefix="/user", tags=["user"])


@router.post("/register", response_model=CreateUserResponse)
async def register(req: CreateUserRequest, db: AsyncSession = Depends(get_db)):
    return await services.create_user(req, db)


@router.get("/me", response_model=UserRead)
async def me(current_user: User = Depends(get_current_user)):
    return await services.read_me(current_user)
