from datetime import datetime

from sqlalchemy import event

from app.core.database.mixins import TimestampMixin


@event.listens_for(TimestampMixin, "before_update", propagate=True)
def timestamp_before_update(mapper, connection, target):
    target.updated_at = datetime.now()
