from datetime import datetime
from enum import Enum

from pydantic import BaseModel, EmailStr, UUID4


class UserRole(str, Enum):
    user = "user"
    admin = "admin"


class CreateUserRequest(BaseModel):
    email: EmailStr
    password: str


class CreateUserResponse(BaseModel):
    email: EmailStr


class UserRead(BaseModel):
    id: UUID4
    email: EmailStr
    created_at: datetime

    model_config = {"from_attributes": True}
