from fastapi import HTTPException, status
from pydantic import EmailStr, TypeAdapter
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import (hash_password)
from app.features.rbac.models import (
    group_has_permissions,
    Permission,
    role_has_permissions,
    user_group,
    user_role
)
from app.features.user.models import User
from app.features.user.schemas import (CreateUserRequest, CreateUserResponse)


async def create_user(req: CreateUserRequest, db: AsyncSession) -> CreateUserResponse:
    email_normalized = str(req.email).lower().strip()

    result = await db.execute(select(User).where(User.email == email_normalized))
    existing_user = result.scalar_one_or_none()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User with this email already exists",
        )

    if len(req.password) < 8:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password too short (minimum 8 characters)",
        )

    user = User(
        email=email_normalized,
        password=hash_password(req.password),
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)

    email_adapter = TypeAdapter(EmailStr)

    return CreateUserResponse(
        email=email_adapter.validate_python(user.email),
    )


async def read_me(current_user: User) -> User:
    return current_user


async def load_user_permission_codes(db: AsyncSession, user_id):
    # Permissions from roles
    stmt_roles = (
        select(Permission.code)
        .select_from(Permission)
        .join(role_has_permissions)
        .join(user_role)
        .where(user_role.c.user_id == user_id)
    )

    # Permissions from groups
    stmt_groups = (
        select(Permission.code)
        .select_from(Permission)
        .join(group_has_permissions)
        .join(user_group)
        .where(user_group.c.user_id == user_id)
    )

    # UNION to remove duplicates
    union_stmt = stmt_roles.union(stmt_groups)

    res = await db.execute(union_stmt)
    return [row[0] for row in res.all()]
