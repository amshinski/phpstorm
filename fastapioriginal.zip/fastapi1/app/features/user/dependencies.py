import uuid

from fastapi import Depends, Header, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database.db import get_db
from app.core.security import verify_token
from app.features.user.models import User
from app.features.user.services import load_user_permission_codes


async def extract_token(
        authorization: str | None = Header(default=None),
        request: Request = None,
) -> str:
    token: str | None = None

    if authorization:
        parts = authorization.split()
        if len(parts) == 2 and parts[0].lower() == "bearer":
            token = parts[1].strip()
        else:
            token = authorization.strip()

    if not token:
        token = request.headers.get("X-Access-Token") or request.query_params.get("access_token")

    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")

    return token


async def get_current_user(
        token: str = Depends(extract_token),
        db: AsyncSession = Depends(get_db),
) -> User:
    try:
        payload = verify_token(token)
        print('get_current_user')
        print(verify_token(token))
        print(token)
        user_id = uuid.UUID(payload.get("sub"))
        print(user_id)
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid auth token")

    res = await db.execute(select(User).where(User.id == user_id))
    user = res.scalars().first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return user


async def user_has_permissions(
        required: list[str],
        current_user: User = Depends(get_current_user),
        db: AsyncSession = Depends(get_db),
):
    user_codes = await load_user_permission_codes(db, current_user.id)
    missing = [c for c in required if c not in user_codes]
    if missing:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"missing_permissions": missing},
        )
    return True


def require_permissions(*codes: str):
    async def dep(_: bool = Depends(lambda: user_has_permissions(list(codes)))):
        return True

    return dep
