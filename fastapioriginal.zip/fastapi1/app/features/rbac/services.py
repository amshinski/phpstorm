# from sqlalchemy.ext.asyncio import AsyncSession
# from app.features.rbac.schemas import ExampleRequest, ExampleResponse


# async def example(req: ExampleRequest, db: AsyncSession) -> ExampleResponse:
#     # TODO: implement real logic using db session
#     # For now return echo to match ExampleResponse
#     return ExampleResponse(id=req.id, example_str=req.example_str)
