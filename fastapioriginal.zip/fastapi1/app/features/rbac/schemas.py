# from pydantic import BaseModel
# from pydantic import UUID4
#
#
# class ExampleRequest(BaseModel):
#     id: UUID4
#     example_str: str
#
#
# class ExampleResponse(BaseModel):
#     id: UUID4
#     example_str: str
