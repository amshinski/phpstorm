from __future__ import annotations

from sqlalchemy import (Column, ForeignKey, String, Table, UniqueConstraint)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database.db import Base, BaseUUID
from app.core.database.mixins import TimestampMixin
from app.features.user.models import User


class Role(BaseUUID, TimestampMixin):
    __tablename__ = "roles"

    name: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, index=True)
    guard_name: Mapped[str] = mapped_column(String(50), nullable=False, index=True)

    __table_args__ = (
        UniqueConstraint("name", "guard_name", name="uq_roles_name_guard"),
    )


class Permission(BaseUUID, TimestampMixin):
    __tablename__ = "permissions"

    # Human-readable name (e.g. "Read Tickets")
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    # Code to use in decorators/dependencies (e.g. "tickets.read")
    code: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    # Optional multi-guard support, mirroring Role
    guard_name: Mapped[str] = mapped_column(String(50), nullable=False, index=True)

    __table_args__ = (
        UniqueConstraint("code", "guard_name", name="uq_permissions_code_guard"),
    )


class Group(BaseUUID, TimestampMixin):
    __tablename__ = "groups"

    name: Mapped[str] = mapped_column(String(100), nullable=False, unique=True)
    guard_name: Mapped[str] = mapped_column(String(50), nullable=False, index=True)

    __table_args__ = (
        UniqueConstraint("name", "guard_name", name="uq_groups_name_guard"),
    )


role_has_permissions = Table(
    "role_has_permissions",
    Base.metadata,
    Column(
        "role_id",
        UUID(as_uuid=True),
        ForeignKey("roles.id", onupdate="NO ACTION", ondelete="CASCADE"),
        primary_key=True,
    ),
    Column(
        "permission_id",
        UUID(as_uuid=True),
        ForeignKey("permissions.id", onupdate="NO ACTION", ondelete="CASCADE"),
        primary_key=True,
    ),
    UniqueConstraint("role_id", "permission_id", name="uq_role_permission"),
)

group_has_permissions = Table(
    "group_has_permissions",
    Base.metadata,
    Column(
        "group_id",
        UUID(as_uuid=True),
        ForeignKey("groups.id", onupdate="NO ACTION", ondelete="CASCADE"),
        primary_key=True,
    ),
    Column(
        "permission_id",
        UUID(as_uuid=True),
        ForeignKey("permissions.id", onupdate="NO ACTION", ondelete="CASCADE"),
        primary_key=True,
    ),
    UniqueConstraint("group_id", "permission_id", name="uq_group_permission"),
)

user_role = Table(
    "user_role",
    Base.metadata,
    Column(
        "user_id",
        UUID(as_uuid=True),
        ForeignKey("users.id", onupdate="NO ACTION", ondelete="CASCADE"),
        primary_key=True,
    ),
    Column(
        "role_id",
        UUID(as_uuid=True),
        ForeignKey("roles.id", onupdate="NO ACTION", ondelete="CASCADE"),
        primary_key=True,
    ),
)

user_group = Table(
    "user_group",
    Base.metadata,
    Column(
        "user_id",
        UUID(as_uuid=True),
        ForeignKey("users.id", onupdate="NO ACTION", ondelete="CASCADE"),
        primary_key=True,
    ),
    Column(
        "group_id",
        UUID(as_uuid=True),
        ForeignKey("groups.id", onupdate="NO ACTION", ondelete="CASCADE"),
        primary_key=True,
    ),
    UniqueConstraint("user_id", "group_id", name="uq_user_group"),
)

User.groups = relationship(
    "Group",
    secondary=user_group,
    back_populates="users",
    passive_deletes=True,
)

Group.users = relationship(
    "User",
    secondary=user_group,
    back_populates="groups",
    passive_deletes=True,
)

User.roles = relationship(
    "Role",
    secondary=user_role,
    back_populates="users",
    passive_deletes=True,

)

Role.users = relationship(
    "User",
    secondary=user_role,
    back_populates="roles",
    passive_deletes=True,
)

Role.permissions = relationship(
    "Permission",
    secondary=role_has_permissions,
    back_populates="roles",
    passive_deletes=True,
)

Permission.roles = relationship(
    "Role",
    secondary=role_has_permissions,
    back_populates="permissions",
    passive_deletes=True,
)

Group.permissions = relationship(
    "Permission",
    secondary=group_has_permissions,
    back_populates="groups",
    passive_deletes=True,
)

Permission.groups = relationship(
    "Group",
    secondary=group_has_permissions,
    back_populates="permissions",
    passive_deletes=True,
)
