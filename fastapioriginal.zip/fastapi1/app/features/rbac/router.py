# from fastapi import APIRouter, Depends
# from sqlalchemy.ext.asyncio import AsyncSession
#
# from app.core.database.db import get_db
# from app.features.rbac import services
# from app.features.rbac.schemas import (
#     ExampleRequest, ExampleResponse,
# )
#
# router = APIRouter(prefix="/rbac", tags=["rbac"])
#
#
# @router.post("/example", response_model=ExampleResponse)
# async def register(req: ExampleRequest, db: AsyncSession = Depends(get_db)):
#     return await services.example(req, db)
