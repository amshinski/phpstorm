from __future__ import annotations

import uuid
from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import (Boolean, DateTime, ForeignKey, String, Text, text, UniqueConstraint)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database.db import Base, BaseUUID
from app.core.database.mixins import TimestampMixin

if TYPE_CHECKING:
    from app.features.user.models import User


class SMSCode(BaseUUID, Base, TimestampMixin):
    __tablename__ = "sms_codes"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "users.id",
            name="fk_sms_codes_user_id_users",
            onupdate="NO ACTION",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )
    code: Mapped[str] = mapped_column(String(8), nullable=False)
    type: Mapped[str] = mapped_column(String(30), nullable=False, server_default="login")

    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    used: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("false"))

    user: Mapped["User"] = relationship("User", back_populates="sms_codes")


class RefreshToken(BaseUUID, Base, TimestampMixin):
    __tablename__ = "refresh_tokens"
    __table_args__ = (UniqueConstraint("token", name="uq_refresh_token_token"),)

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "users.id",
            name="fk_refresh_tokens_user_id_users",
            onupdate="NO ACTION",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )
    token: Mapped[str] = mapped_column(Text, nullable=False)

    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    revoked: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("false"))

    user: Mapped["User"] = relationship("User", back_populates="refresh_tokens")
