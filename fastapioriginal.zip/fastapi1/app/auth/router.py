from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import services
from app.auth.schemas import (ConfirmCodeRequest, ConfirmCodeResponse, SendCodeRequest, SendCodeResponse, TokenResponse)
from app.core.database.db import get_db

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/send-code", response_model=SendCodeResponse)
async def send_code(req: SendCodeRequest, db: AsyncSession = Depends(get_db)):
    return await services.send_code(req, db)


@router.post("/confirm-code", response_model=ConfirmCodeResponse)
async def confirm_code(req: ConfirmCodeRequest, db: AsyncSession = Depends(get_db)):
    return await services.confirm_code(req, db)


@router.post("/refresh", response_model=TokenResponse)
async def refresh(token: str, db: AsyncSession = Depends(get_db)):
    return await services.refresh_token(token, db)
