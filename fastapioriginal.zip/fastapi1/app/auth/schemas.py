from pydantic import BaseModel, EmailStr


class SendCodeRequest(BaseModel):
    email: EmailStr = 'test@email.com'
    password: str = '12345678'
    remember_me: bool = False


class SendCodeResponse(BaseModel):
    action: str = 'auth'
    sms_index: int
    verification_code: str
    code: str  # debug


class ConfirmCodeRequest(BaseModel):
    email: EmailStr = 'test@email.com'
    code: str = '1234'
    type: str = 'sms'
    verification_code: str


class ConfirmCodeResponse(BaseModel):
    access_token: str
    refresh_token: str
    preview_mode: bool = False
    user_name: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
