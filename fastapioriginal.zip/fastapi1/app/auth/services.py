import random
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, status
from jose import JWTError
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.models import RefreshToken, SMSCode
from app.auth.schemas import (ConfirmCodeRequest, ConfirmCodeResponse, SendCodeRequest, SendCodeResponse, TokenResponse)
from app.core.config import settings
from app.core.security import (create_access_token, create_refresh_token, hash_password, verify_password, verify_token)
from app.features.user.models import User


async def send_code(req: SendCodeRequest, db: AsyncSession) -> SendCodeResponse:
    email = str(req.email).lower().strip()

    # Find user
    res = await db.execute(select(User).where(User.email == email))
    user: User | None = res.scalar_one_or_none()
    if not user:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid email or password")

    # Verify password
    ok, needs_rehash = verify_password(req.password, user.password)
    if not ok:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid email or password")
    if needs_rehash:
        user.password = hash_password(req.password)
        db.add(user)
        await db.commit()

    code = f"{random.randint(0, 9999):04d}"
    now = datetime.now(timezone.utc)
    expires = now + timedelta(minutes=settings.SMS_CODE_EXPIRE_MINUTES)

    # Find existing SMS row for this user (latest one)
    res = await db.execute(
        select(SMSCode)
        .where(SMSCode.user_id == user.id)
        .order_by(SMSCode.created_at.desc())
        .limit(1)
    )
    sms: SMSCode | None = res.scalar_one_or_none()

    if sms:
        # Update existing row
        sms.code = code
        sms.type = 'login'
        sms.created_at = now
        sms.expires_at = expires
        sms.used = False
        db.add(sms)
    else:
        # Create new row
        sms = SMSCode(
            user_id=user.id,
            code=code,
            type='login',
            created_at=now,
            expires_at=expires,
            used=False,
        )
        db.add(sms)

    await db.commit()

    return SendCodeResponse(
        action="auth",
        sms_index=0,
        verification_code="",
        code=code,
    )


async def confirm_code(req: ConfirmCodeRequest,
                       db: AsyncSession) -> ConfirmCodeResponse:
    sms = (await db.execute(
        select(SMSCode)
        .where(
            SMSCode.code == req.code,
            SMSCode.used.is_(False),
            SMSCode.expires_at > datetime.now(timezone.utc),
        )
        .order_by(desc(SMSCode.created_at))
    )).scalars().first()

    if not sms:
        raise HTTPException(400, "Invalid or expired code")

    sms.used = True
    await db.commit()

    user: User | None = await db.get(User, sms.user_id)
    if user is None:
        raise HTTPException(404, "User not found")

    at = create_access_token(user.id)
    rt_str = create_refresh_token(user.id)
    rt = RefreshToken(
        user_id=user.id,
        token=rt_str,
        expires_at=datetime.now(timezone.utc) + timedelta(
            days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
    )
    db.add(rt)
    await db.commit()

    return ConfirmCodeResponse(
        access_token=at,
        refresh_token=rt_str,
        user_name=str(user.email),
    )


async def refresh_token(token: str, db: AsyncSession) -> TokenResponse:
    try:
        verify_token(token)
    except JWTError:
        raise HTTPException(401, "Invalid refresh token")

    rt = (await db.execute(
        select(RefreshToken)
        .where(
            RefreshToken.token == token,
            RefreshToken.revoked.is_(False),
            RefreshToken.expires_at > datetime.now(timezone.utc),
        )
    )).scalars().first()

    if not rt:
        raise HTTPException(401, "Expired or revoked refresh token")

    user: User | None = await db.get(User, rt.user_id)
    if user is None:
        raise HTTPException(404, "User not found")

    new_at = create_access_token(user.id)
    return TokenResponse(access_token=new_at, refresh_token=token)
