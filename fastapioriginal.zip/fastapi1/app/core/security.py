import hmac
import os
import uuid
from datetime import datetime, timedelta, timezone

import unicodedata
from jose import jwt
from passlib.context import CryptContext

from app.core.config import settings

pwd_context = CryptContext(
    schemes=["argon2"],
    deprecated="auto",
    argon2__memory_cost=102400,
    argon2__time_cost=2,
    argon2__parallelism=8,
)

PEPPER = os.getenv("PASSWORD_PEPPER", "")


def _normalize(password: str) -> str:
    # Normalize to avoid weird Unicode edge cases
    return unicodedata.normalize("NFKC", password)


def hash_password(password: str) -> str:
    pw = _normalize(password) + PEPPER
    return pwd_context.hash(pw)


def verify_password(plain_password: str, password_hash: str) -> tuple[bool, bool]:
    """Returns (is_valid, needs_rehash)."""
    pw = _normalize(plain_password) + PEPPER
    valid = pwd_context.verify(pw, password_hash)
    needs = False
    if valid and pwd_context.needs_update(password_hash):
        needs = True
    return valid, needs


def constant_time_equal(a: str, b: str) -> bool:
    return hmac.compare_digest(a, b)


def create_access_token(user_id: uuid.UUID) -> str:
    expire = datetime.now(timezone.utc) + timedelta(
        minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode = {"sub": str(user_id), "exp": expire}
    return jwt.encode(to_encode, settings.JWT_SECRET_KEY, algorithm=settings.ALGORITHM)


def create_refresh_token(user_id: uuid.UUID) -> str:
    expire = datetime.now(timezone.utc) + timedelta(
        days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode = {"sub": str(user_id), "exp": expire}
    return jwt.encode(to_encode, settings.JWT_SECRET_KEY, algorithm=settings.ALGORITHM)


def verify_token(token: str) -> dict:
    return jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=[settings.ALGORITHM])
