from alembic.autogenerate import renderers
from alembic.operations import ops

@renderers.dispatch_for(ops.CreateTableOp)
def reorder_columns(autogen_context, op):
    """Force `id` column to be first in CREATE TABLE statements."""
    cols = list(op.columns)
    cols.sort(key=lambda c: 0 if getattr(c, "name", None) == "id" else 1)
    op.columns = cols
    return autogen_context.impl.create_table(op)
