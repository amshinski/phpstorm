import importlib
import pkgutil

import app


def import_all_models() -> None:
    """
    Import every module named 'models' under the 'app' package so that
    SQLAlchemy models are registered on Base.metadata for Alembic autogenerate.
    """
    prefix = app.__name__ + "."
    for _, module_name, is_pkg in pkgutil.walk_packages(app.__path__, prefix):
        # Skip non-app code
        if ".alembic" in module_name or ".tests" in module_name:
            continue
        # Import any ...*.models (e.g., app.features.user.models, app.auth.models)
        if module_name.endswith(".models"):
            importlib.import_module(module_name)
