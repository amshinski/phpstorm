import importlib
import pkgutil

import app.features


def import_all_events():
    """Import all events.py modules inside app/features/*/."""
    package = app.features
    package_path = package.__path__

    for _, module_name, is_pkg in pkgutil.walk_packages(package_path, package.__name__ + "."):
        if module_name.endswith(".events"):
            importlib.import_module(module_name)
