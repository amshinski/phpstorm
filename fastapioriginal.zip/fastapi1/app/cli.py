import importlib
import pkgutil

import typer

from app import commands as commands_pkg

app = typer.Typer(help="Project management CLI")


def auto_register_commands(app: typer.Typer):
    pkg_name = commands_pkg.__name__
    for m in pkgutil.iter_modules(commands_pkg.__path__):
        mod = importlib.import_module(f"{pkg_name}.{m.name}")

        # If the module exposes a Typer app, add it as a sub-typer (Pattern B support)
        if hasattr(mod, "app") and isinstance(getattr(mod, "app"), typer.Typer):
            name = getattr(mod, "COMMAND_NAME", m.name.replace("_", "-"))
            app.add_typer(mod.app, name=name)
            continue

        # Otherwise, look for a single function `main`
        func = getattr(mod, "main", None)
        if callable(func):
            name = getattr(mod, "COMMAND_NAME", m.name.replace("_", "-"))
            app.command(name)(func)
        else:
            typer.echo('Module has no usable entrypoint')
            pass


auto_register_commands(app)

if __name__ == "__main__":
    app()
