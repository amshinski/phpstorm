import asyncio
import sys
import uuid

import typer
from dotenv import load_dotenv
from sqlalchemy import select
from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncEngine, AsyncSession, create_async_engine

from app.core.config import settings
from app.core.database.db import Base
from app.core.security import hash_password
from app.features.user.models import User

# Windows event loop policy (prevents asyncio + SQLAlchemy weirdness on Win)
if sys.platform.startswith("win"):
    from asyncio import WindowsSelectorEventLoopPolicy

    asyncio.set_event_loop_policy(WindowsSelectorEventLoopPolicy())

# Load .env from project root (cwd) if present
load_dotenv()

COMMAND_NAME = "seed"


async def _init_db(engine: AsyncEngine):
    """Create all tables if they don’t already exist."""
    async with engine.begin() as conn:
        # Import models so SQLAlchemy knows about all mappers
        import app.features.user.models  # noqa: F401
        import app.auth.models  # noqa: F401
        await conn.run_sync(Base.metadata.create_all)


async def _seed(session: AsyncSession):
    """Insert 2 test users if they don't already exist."""
    users = [
        {
            "email": "test@email.com",
            "password": "Password123!",
        },
        {
            "email": "test2@email.com",
            "password": "Password123!",
        },
    ]

    for u in users:
        email = u["email"].lower().strip()
        res = await session.execute(select(User).where(User.email == email))
        if res.scalar_one_or_none():
            continue

        user = User(
            id=uuid.uuid4(),
            email=email,
            password=hash_password(u["password"]),
            name=email.split("@")[0],
        )
        session.add(user)

    await session.commit()


def _engine(echo: bool):
    db_url = str(settings.sqlalchemy_database_uri)
    return create_async_engine(db_url, echo=echo)


async def _run(init_db: bool, echo: bool):
    engine = _engine(echo=echo)
    try:
        if init_db:
            await _init_db(engine)

        async_session = async_sessionmaker(
            engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        async with async_session() as session:
            await _seed(session)

        typer.secho("Seed complete: users", fg=typer.colors.GREEN)

    finally:
        await engine.dispose()


def main(
        init_db: bool = typer.Option(True, "--init-db/--no-init-db", help="Create tables before seeding."),
        echo: bool = typer.Option(False, "--echo", help="Enable SQLAlchemy engine echo."),
):
    """Run database seeding (test users only)."""
    asyncio.run(_run(init_db=init_db, echo=echo))
