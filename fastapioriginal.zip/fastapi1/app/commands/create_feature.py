import re
from pathlib import Path

import typer

COMMAND_NAME = "create-feature"


# TODO: add cruds to services

def _to_snake(s: str) -> str:
    s = re.sub(r"[^0-9a-zA-Z]+", "_", s).strip("_").lower()
    if re.match(r"^\d", s):
        s = f"feat_{s}"
    s = re.sub(r"_+", "_", s)
    return s or "unnamed"


def _to_kebab(s: str) -> str:
    s = re.sub(r"[^0-9a-zA-Z]+", "-", s).strip("-").lower()
    if re.match(r"^\d", s):
        s = f"feat-{s}"
    s = re.sub(r"-+", "-", s)
    return s or "unnamed"


def main(
        name: str = typer.Argument(..., help="Feature name (foo, foo-bar)")
):
    """Create a new feature under app/features/<name>/ with boilerplate files."""
    commands_dir = Path(__file__).resolve().parent
    app_dir = commands_dir.parent
    features_dir = app_dir / "features"

    module_name = _to_snake(name)  # folder/package name
    route_name = _to_kebab(name)  # URL/tag name
    pkg_dir = features_dir / module_name

    if pkg_dir.exists():
        typer.secho(f"ERROR: {pkg_dir} already exists.", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    features_dir.mkdir(parents=True, exist_ok=True)
    pkg_dir.mkdir()

    # --- templates ---
    init_py = f"""# {module_name} feature
from .router import router  # re-export for easy include
"""

    models_py = """from __future__ import annotations
# from typing import TYPE_CHECKING

import uuid
from datetime import datetime

from sqlalchemy import (
    String,
    DateTime,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database.db import Base

# if TYPE_CHECKING:
#     from <some_path> import <some_model>


class Example(Base):
    __tablename__ = "example"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default=text("uuid_generate_v4()"),
    )
    example_str: Mapped[str] = mapped_column(String(255), unique=False, nullable=True, index=False)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False
    )
"""

    schemas_py = """from pydantic import BaseModel
from pydantic import UUID4


class ExampleRequest(BaseModel):
    id: UUID4
    example_str: str


class ExampleResponse(BaseModel):
    id: UUID4
    example_str: str
"""

    services_py = """from sqlalchemy.ext.asyncio import AsyncSession
from .schemas import ExampleRequest, ExampleResponse


async def example(req: ExampleRequest, db: AsyncSession) -> ExampleResponse:
    # TODO: implement real logic using db session
    # For now return echo to match ExampleResponse
    return ExampleResponse(id=req.id, example_str=req.example_str)
"""

    router_py = f"""from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.features.{module_name}.schemas import (
    ExampleRequest, ExampleResponse,
)
from app.core.database.db import get_db
from app.features.{module_name} import services

router = APIRouter(prefix="/{route_name}", tags=["{route_name}"])


@router.post("/example", response_model=ExampleResponse)
async def register(req: ExampleRequest, db: AsyncSession = Depends(get_db)):
    return await services.example(req, db)
"""

    dependencies_py = ""  # empty as requested

    # --- write files ---
    (pkg_dir / "__init__.py").write_text(init_py, encoding="utf-8")
    (pkg_dir / "models.py").write_text(models_py, encoding="utf-8")
    (pkg_dir / "schemas.py").write_text(schemas_py, encoding="utf-8")
    (pkg_dir / "services.py").write_text(services_py, encoding="utf-8")
    (pkg_dir / "router.py").write_text(router_py, encoding="utf-8")
    (pkg_dir / "dependencies.py").write_text(dependencies_py, encoding="utf-8")

    typer.secho(f"Created feature: {pkg_dir}", fg=typer.colors.GREEN)
    for f in ["__init__.py", "models.py", "schemas.py", "services.py", "router.py",
              "dependencies.py"]:
        typer.echo(f" - {f}")
    typer.echo(
        f"Tip: include it in app/main.py -> app.include_router(app.features.{module_name}.router)"
    )
