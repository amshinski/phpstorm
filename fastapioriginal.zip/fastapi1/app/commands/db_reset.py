import asyncio

import typer
from sqlalchemy import text

from app.core.database.db import engine

COMMAND_NAME = "db-reset"


def main(confirm: bool = typer.Option(False, "--yes", "-y", help="Reset database")):
    """Reset database."""
    if not confirm:
        typer.echo("Add --yes to actually reset the DB.")
        raise typer.Exit(1)
    asyncio.run(_reset())


async def _reset():
    async with engine.begin() as conn:
        # one statement per execute – asyncpg hates multi-statement prepares
        await conn.execute(text('DROP SCHEMA IF EXISTS public CASCADE'))
        await conn.execute(text('CREATE SCHEMA public'))
        # ensure uuid_generate_v4() exists
        await conn.execute(text('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"'))
    typer.secho("Database schema reset.", fg=typer.colors.GREEN)
