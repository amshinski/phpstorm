import re
from pathlib import Path

import typer

COMMAND_NAME = "create-command"


def _to_snake(s: str) -> str:
    s = re.sub(r"[^0-9a-zA-Z]+", "_", s).strip("_").lower()
    if re.match(r"^\d", s):
        s = f"cmd_{s}"
    s = re.sub(r"_+", "_", s)
    return s or "unnamed"


def _to_kebab(s: str) -> str:
    s = re.sub(r"[^0-9a-zA-Z]+", "-", s).strip("-").lower()
    if re.match(r"^\d", s):
        s = f"cmd-{s}"
    s = re.sub(r"-+", "-", s)
    return s or "unnamed"


def main(
        name: str = typer.Argument(...,
                                   help="Command name (any format: foo, foo_bar, foo-bar)"),
        description: str = typer.Option("Describe your command", "--description", "-d"),
        force: bool = typer.Option(False, "--force", "-f", help="Overwrite if exists"),
):
    """Create a new command under app/commands/. Example: create-command test_command -d "Description"""""
    commands_dir = Path(__file__).resolve().parent
    module_name = _to_snake(name)
    command_name = _to_kebab(name)
    target = commands_dir / f"{module_name}.py"

    if target.exists() and not force:
        typer.secho(f"ERROR: {target} already exists. Use --force to overwrite.",
                    fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    template = f'''import typer

COMMAND_NAME = "{command_name}"


def main():
    """{description}"""
    typer.echo('{command_name}')
'''

    target.write_text(template, encoding="utf-8")
    typer.secho(f"Created {target}", fg=typer.colors.GREEN)
    typer.echo(f"- Module: {module_name}")
    typer.echo(f"- COMMAND_NAME: {command_name}")
    typer.echo("Tip: run `python -m app.cli --help` to see it.")
