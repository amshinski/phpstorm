import secrets

import typer

COMMAND_NAME = "generate-secret"


def main(length: int = 32):
    """Generate a secure URL-safe secret."""
    typer.echo(secrets.token_urlsafe(length))
