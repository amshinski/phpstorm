import typer

COMMAND_NAME = "ping"


def main():
    """Simple health check."""
    typer.echo("pong")
