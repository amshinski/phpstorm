import os
import sys
from logging.config import fileConfig

from alembic import context  # noqa: F401
from alembic.operations import ops as alembic_ops
from sqlalchemy import engine_from_config, pool

# PROJECT_ROOT must be before models import and all app. imports
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Import models so they register their tables
from app.core.database.models_importer import import_all_models

import_all_models()  # noqa

# Import settings and Base to populate metadata
from app.core.config import settings
from app.core.database.db import Base

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
fileConfig(config.config_file_name)

# add your model's MetaData object here
# for 'autogenerate' support
# from myapp import mymodel
# target_metadata = mymodel.Base.metadata
# target_metadata = None

# Target metadata for 'autogenerate'
target_metadata = Base.metadata

_UUID_EXT_SQL = 'CREATE EXTENSION IF NOT EXISTS "uuid-ossp";'


def _inject_uuid_extension(directives):
    """Ensure CREATE EXTENSION uuid-ossp is the first op in upgrade()."""
    if not directives:
        return
    migration_script = directives[0]
    upgrade_ops = getattr(migration_script, "upgrade_ops", None)
    if not upgrade_ops or not getattr(upgrade_ops, "ops", None):
        # even if no other ops, still inject to guarantee extension
        upgrade_ops = migration_script.upgrade_ops

    # Skip if already present
    for op in upgrade_ops.ops:
        if isinstance(op, alembic_ops.ExecuteSQLOp):
            sql_text = str(op.sqltext).strip().lower()
            if sql_text == _UUID_EXT_SQL.lower():
                return

    upgrade_ops.ops.insert(0, alembic_ops.ExecuteSQLOp(_UUID_EXT_SQL))


def _col_order_key(col):
    # Normalize to a string so tuple comparison never sees None
    name = getattr(col, "name", None)
    if not isinstance(name, str):
        name = ""
    if name == "id":
        group = 0
    elif name in ("created_at", "updated_at"):
        group = 2
    else:
        group = 1
    # Sort by (group, name); Python sort is stable, so original order within
    # same group is preserved.
    return group, name


def _reorder_create_table_columns(directives):
    """Mutate CreateTableOp columns in-place to enforce our order."""
    for directive in directives:
        # MigrationScript has .upgrade_ops and .downgrade_ops
        if hasattr(directive, "upgrade_ops"):
            _reorder_ops(directive.upgrade_ops)
        if hasattr(directive, "downgrade_ops"):
            _reorder_ops(directive.downgrade_ops)


def _reorder_ops(container):
    # container.ops may include nested containers (BatchOps, UpgradeOps, etc.)
    for op in getattr(container, "ops", []):
        if isinstance(op, alembic_ops.CreateTableOp):
            cols = list(op.columns or [])
            cols.sort(key=_col_order_key)
            op.columns = cols
        elif hasattr(op, "ops"):  # nested ops
            _reorder_ops(op)


def _to_sync_url(url: str) -> str:
    """Convert async URLs to psycopg3's sync driver for Alembic."""
    # Convert asyncpg → psycopg3 sync
    if "+asyncpg" in url:
        return url.replace("+asyncpg", "+psycopg")
    # If already psycopg3 async
    if "+psycopg_async" in url:
        return url.replace("+psycopg_async", "+psycopg")
    return url


def get_url() -> str:
    url = str(getattr(settings, "sqlalchemy_database_uri",
                      getattr(settings, "DATABASE_URL", "")))
    if not url:
        raise RuntimeError("Database URL is not set in settings.")
    return _to_sync_url(url)


def _process_revision_directives(ctx, rev, directives):
    """Run all our autogen tweaks in one place."""
    _inject_uuid_extension(directives)
    _reorder_create_table_columns(directives)


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode."""
    url = get_url()
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        compare_type=True,
        compare_server_default=True,
        process_revision_directives=_process_revision_directives,
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode."""
    configuration = config.get_section(config.config_ini_section)
    configuration["sqlalchemy.url"] = get_url()

    connectable = engine_from_config(
        configuration,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
        future=True,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
            compare_server_default=True,
            process_revision_directives=_process_revision_directives,
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
