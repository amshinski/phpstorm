#!/bin/bash
#
# check_style.sh – static analysis checker for Python projects
#
# This script traverses all Python modules in a project and runs a suite of
# tools to ensure that the code follows widely‑used Python conventions.  It
# leverages Ruff to lint for PEP 8 style errors, naming conventions and import
# order; runs Ruff's formatter to verify that the code is formatted like
# Black; invokes mypy to perform static type checking (PEP 484/PEP 604/PEP 585);
# and uses pydocstyle to check docstrings (PEP 257).  The goal is to
# automatically detect violations of the guidelines described in PEP 8 and
# related PEPs, such as using snake_case for functions and variables【933879342018012†L250-L274】,
# surrounding top‑level definitions with blank lines【933879342018012†L359-L389】, adhering to four‑space indentation【933879342018012†L538-L547】,
# writing structured docstrings【933879342018012†L931-L1002】 and adopting modern type hints like
# `list[int]` and `int | str`【96905578763751†L64-L99】.
#
# Usage: bash check_style.sh [PATH]
#
# If no PATH is provided, the current directory is assumed.  The script exits
# with a non‑zero status if any check fails.  Before running the script for
# the first time, install the required tools:
#
#   python -m pip install --upgrade ruff mypy pydocstyle
#
# Ruff combines several popular linters (`pycodestyle`, `pyflakes`, `pep8-naming`,
# `isort`, `pydocstyle` and `pyupgrade`), so using it keeps the command simple.
# See: https://docs.astral.sh/ruff/ for details.

set -e

# Determine the directory to check (default is current directory)
PROJECT_DIR="${1:-.}"

echo "Checking Python style in $PROJECT_DIR…"

# 1. Lint code with Ruff.  The `--select` flag enables multiple rule families:
#    E   – PEP 8 style violations (pycodestyle) such as whitespace and line length【933879342018012†L538-L547】;
#    F   – pyflakes checks for syntax errors and unused imports【933879342018012†L1489-L1609】;
#    N   – pep8‑naming rules for naming conventions【933879342018012†L250-L274】;
#    I   – import ordering (isort);
#    ANN – missing type annotations (flake8‑annotations);
#    D   – docstring formatting and presence (pydocstyle)【933879342018012†L931-L1002】;
#    UP  – pyupgrade to suggest modern syntax like generics on built‑ins and union
#          types using `|`【96905578763751†L64-L99】.
ruff check "$PROJECT_DIR" \
  --select E,F,N,I,ANN,D,UP \
  --ignore D100,D101,D102,D103,D104,D205,D212,D213,D400,D401,D415,UP037,I001,ANN001,ANN201,ANN202,E402,E501 \
  --target-version=py310

# 2. Check that files would be formatted the same as Black.  Ruff's formatter
#    supports Black style formatting (with an 88‑character line limit by
#    default)【933879342018012†L1628-L1646】.  Use `--line-length` to match PEP 8's 79‑character
#    recommendation if desired.
ruff format "$PROJECT_DIR" --check

# 3. Run mypy in strict mode to verify type hints.  Mypy checks that all
#    function parameters and return types are annotated【559966613105353†L720-L747】 and that
#    optional/union types use the pipe syntax where appropriate【96905578763751†L64-L99】.
mypy --strict "$PROJECT_DIR"

# 4. Verify that docstrings are present and properly formatted (PEP 257) using
#    pydocstyle.  This catches missing docstrings on public functions and
#    classes, incorrect docstring style or formatting【933879342018012†L931-L1002】.
pydocstyle --ignore=D100,D101,D102,D103,D104,D205,D212,D213,D400,D401,D415,UP037,I001,ANN001,ANN201,ANN202,E402,E501 "$PROJECT_DIR"

echo "All checks passed!"