import HeroCarousel, {HeroSlide} from '@/app/components/HeroCarousel';
import ServiceCard, {ServiceCardItem} from '@/app/components/ServiceCard';
import FeatureTiles, {FeatureItem} from '@/app/components/FeatureTiles';
import Advantages, {AdvantageItem} from '@/app/components/Advantages';
import NewsCarousel, {NewsItem} from '@/app/components/NewsCarousel';
import CurrencyBox, {CurrencyItem} from '@/app/components/CurrencyBox';
import InsuranceSection, {InsuranceTabs,} from "@/app/components/InsuranceSection";

import hero1 from '@/../public/hero1.png';

import cup from '@/../public/hero1.png';
import sliders from '@/../public/hero1.png';
import squares from '@/../public/hero1.png';
import coins from '@/../public/hero1.png';
import refresh from '@/../public/hero1.png';
import clock from '@/../public/hero1.png';


const slides: HeroSlide[] = [
    {
        title: 'Точный расчёт',
        text:
            'Страховая программа с гарантированным доходом до 16,16% годовых.\n\nДоступны варианты в рублях и в валюте (¥, $)',
        link: {href: '/calc', label: 'Рассчитать'},
        image: hero1,
    },
    {
        title: 'Второй слайд',
        text: 'Короткий подзаголовок или оффер.',
        link: {href: '/product', label: 'Подробнее'},
        image: hero1
    },
    {
        title: 'Третий слайд',
        text: 'lorem ipsum',
        link: {href: '/product', label: 'Подробнее'},
        image: hero1
    },
];

const cards: ServiceCardItem[] = [
    {
        title: 'Накопления и защита',
        text: 'Копилка онлайн и не только',
        image: hero1, // replace with your coin+shield PNG
        link: '/services/savings',
    },
    {
        title: 'Инвестиции и защита',
        text: 'PRO инвестиции',
        image: hero1, // replace with your percent+shield PNG
        link: '/services/invest',
    },
    {
        title: 'Защита',
        text: 'Профессиональная защита',
        image: hero1, // replace with your shield PNG
        link: '/services/protect',
    },
];

const lifeFeatures: FeatureItem[] = [
    {text: 'Гарантированные накопления к определённому сроку или возрасту застрахованного (взрослого / ребёнка)'},
    {text: 'Гарантированное получение дохода по накопительным программам. Доходность указывается в договоре'}, // #02 (blue)
    {text: 'Возможность получить доход от инвестиций в базовый актив по инвестиционным программам'},
    {text: 'Страховая защита по широкому набору рисков для жизни и здоровья вас и ваших близких'},
    {text: 'Социальный налоговый вычет — возможность вернуть до 19 500 рублей в год или единовременно при выборе программы на срок от 5 лет (ст. 219 НК РФ)'},
    {text: 'Юридическая защита страховых накоплений при разводе / разделе имущества (ГК РФ; СК РФ; Закон №4015-1)'},
    {text: 'Возможность назначить Выгодоприобретателя для выплаты по любому из страховых рисков, указанных в договоре'},
    {text: 'Отсутствие налогообложения выплат по «рисковым» (не связанным с «Дожитием») событиям (НК РФ ст. 213)'},   // #08 (light blue)
];

const advantages: AdvantageItem[] = [
    {
        title: 'Лидеры рынка',
        text:
            'Страховая компания «СОГАЗ-ЖИЗНЬ» входит в Страховую Группу «СОГАЗ» — лидера российского страхового рынка с высокими рейтингами надёжности.',
        image: cup,
    },
    {
        title: 'Гибкие условия по программам страхования',
        text:
            'Возможность выбора различных параметров договора (риски, срок, сумма, график оплаты и др.) для ваших целей.',
        image: sliders,
    },
    {
        title: 'Широкий выбор дополнительных сервисов',
        text:
            'Онлайн-оформление социального налогового вычета, консьерж-услуги, телемедицинские сервисы в Едином мобильном приложении «СОГАЗ» и многое другое.',
        image: squares,
    },
    {
        title: 'Выплаты без ожидания завершения договора',
        text:
            'По ряду программ выгодоприобретателям или наследникам не требуется ждать окончания договора для получения выплат в связи с уходом из жизни застрахованного лица.',
        image: coins,
    },
    {
        title: 'Изменение договора при различных ситуациях',
        text:
            'Можно перевести договор в оплаченный с уменьшенными страховыми суммами, если нет возможности далее оплачивать взносы, не отказываясь полностью от программы.',
        image: refresh,
    },
    {
        title: 'Льготный период оплаты взносов',
        text:
            'До 30 календарных дней на оплату очередных взносов в случае невозможности их внесения в установленный срок.',
        image: clock,
    },
];

const news: NewsItem[] = [
    {
        id: 1,
        date: '8 ноября 2024',
        title:
            'СОГАЗ является страховщиком российского атомного ледокола «Чукотка»',
        image: hero1,
        href: '/news/1',
    },
    {
        id: 2,
        date: '8 ноября 2024',
        title:
            'СОГАЗ является страховщиком российского атомного ледокола «Чукотка»',
        href: '/news/2',
    },
    {
        id: 3,
        date: '8 ноября 2024',
        title:
            'СОГАЗ является страховщиком российского атомного ледокола «Чукотка»',
        href: '/news/3',
    },
];

const currencies: CurrencyItem[] = [
    {code: 'USD', value: 79.67, trend: 'down'},
    {code: 'EUR', value: 92.33, trend: 'up'},
];

const insuranceData: InsuranceTabs = {
    savings: [
        { id: 1, title: "Копилка онлайн", href: "/prod/1", icon: hero1 },
        { id: 2, title: "Уверенный старт", href: "/prod/2", icon: hero1 },
        { id: 3, title: "+13% онлайн", href: "/prod/3", icon: hero1 },
        { id: 4, title: "Точный расчёт", href: "/prod/4", icon: hero1 },
        { id: 5, title: "Премиум плюс", href: "/prod/5", icon: hero1 }, // full width on mobile
    ],
    investments: [
        { id: 6, title: "Инвест-копилка", href: "/prod/6", icon: hero1 },
        { id: 7, title: "Надёжный портфель", href: "/prod/7", icon: hero1 },
        { id: 8, title: "Бонус +%", href: "/prod/8", icon: hero1 },
        { id: 9, title: "Аллокация-про", href: "/prod/9", icon: hero1 },
        { id: 10, title: "Инвест-премиум", href: "/prod/10", icon: hero1 },
    ],
    protection: [
        { id: 11, title: "Защита семьи", href: "/prod/11", icon: hero1 },
        { id: 12, title: "Детский щит", href: "/prod/12", icon: hero1 },
        { id: 13, title: "Защита дохода", href: "/prod/13", icon: hero1 },
        { id: 14, title: "Расширенная медицина", href: "/prod/14", icon: hero1 },
        { id: 15, title: "Премиум защита", href: "/prod/15", icon: hero1 },
    ],
};

export default function Home() {
    return (
        <main className="mx-auto max-w-7xl p-4 md:p-8">
            <HeroCarousel slides={slides} className="mt-6" autoPlayMs={3000} />

            {/* Section header */}
            <section className="mt-10 md:mt-16">
                <div className="flex flex-wrap items-center justify-between gap-4">
                    <h2 className="text-3xl font-semibold text-slate-900">Страхование</h2>

                    {/* segmented control */}
                    <div className="flex rounded-2xl ring-1 ring-[#0A1DB7]/40 p-1">
                        <a
                            href="/buy"
                            className="rounded-xl px-5 py-2 text-sm font-medium text-[#0A1DB7] ring-1 ring-transparent hover:bg-[#0A1DB7]/5 focus:outline-none focus-visible:ring-[#0A1DB7]
                         bg-white shadow-sm"
                        >
                            КУПИТЬ
                        </a>
                        <a
                            href="/activate"
                            className="rounded-xl px-5 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50"
                        >
                            АКТИВИРОВАТЬ
                        </a>
                    </div>
                </div>

                {/* Cards grid */}
                <div className="mt-6 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
                    {cards.map((c, idx) => (
                        <ServiceCard key={idx} item={c} />
                    ))}
                </div>

                {/* "Все услуги" button */}
                <div className="mt-6">
                    <a
                        href="/services"
                        className="inline-flex items-center gap-2 rounded-xl bg-[#0A1DB7] px-4 py-2 text-sm font-medium text-white hover:bg-[#08209a]"
                    >
                        Все услуги
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden>
                            <path d="M9 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round"
                                  strokeLinejoin="round" />
                        </svg>
                    </a>
                </div>
            </section>

            <InsuranceSection data={insuranceData} className="mt-16" />

            {/* Страхование жизни — это */}
            <section className="mt-14 md:mt-20">
                <div className="mb-6 flex items-center justify-between gap-4">
                    <h2 className="text-3xl font-semibold text-slate-900">
                        Страхование жизни — это
                    </h2>
                    <a
                        href="/life/details"
                        className="inline-flex items-center gap-2 rounded-xl bg-[#0A1DB7] px-4 py-2 text-sm font-medium text-white hover:bg-[#08209a]"
                    >
                        Подробнее
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden>
                            <path d="M9 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round"
                                  strokeLinejoin="round" />
                        </svg>
                    </a>
                </div>

                <FeatureTiles items={lifeFeatures} />
            </section>

            {/* Преимущества страхования жизни в СОГАЗ-Жизнь */}
            <section className="mt-14 md:mt-20">
                <div className="mb-6 flex items-center justify-between gap-4">
                    <h2 className="text-3xl font-semibold text-slate-900">
                        Преимущества страхования жизни в СОГАЗ-Жизнь
                    </h2>
                    <a
                        href="/life/benefits"
                        className="inline-flex items-center gap-2 rounded-xl bg-[#0A1DB7] px-4 py-2 text-sm font-medium text-white hover:bg-[#08209a]"
                    >
                        Подробнее
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden>
                            <path d="M9 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round"
                                  strokeLinejoin="round" />
                        </svg>
                    </a>
                </div>

                <Advantages items={advantages} />
            </section>

            {/* Новости и статьи */}
            <section className="flex items-start gap-8">
                {/* Left: News */}
                <div className="flex-1">
                    <h2 className="text-4xl font-semibold tracking-tight text-slate-900 mb-6">
                        Новости и статьи
                    </h2>
                    <NewsCarousel items={news} className="" />
                </div>

                {/* Right: Currency box */}
                <aside className="w-full max-w-[360px]">
                    <h2 className="text-4xl font-semibold tracking-tight text-slate-900 mb-6">
                        Курс валют ЦБ
                    </h2>
                    <CurrencyBox items={currencies} />
                </aside>
            </section>
        </main>
    );
}
