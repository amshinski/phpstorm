'use client';

import Image, {StaticImageData} from 'next/image';
import clsx from 'clsx';
import {useRef, useState, useEffect} from 'react';

export type AdvantageItem = {
    title: string;
    text: string;
    image: string | StaticImageData;
    alt?: string;
};

type Props = {
    items: AdvantageItem[];
    className?: string;
};

export default function Advantages({items, className}: Props) {
    const trackRef = useRef<HTMLDivElement | null>(null);
    const [active, setActive] = useState(0);

    useEffect(() => {
        const el = trackRef.current;
        if (!el) return;

        const onScroll = () => {
            const w = el.clientWidth;
            const i = Math.round(el.scrollLeft / w);
            setActive(i);
        };

        el.addEventListener('scroll', onScroll, {passive: true});
        return () => el.removeEventListener('scroll', onScroll);
    }, []);

    const scrollToIdx = (idx: number) => {
        const el = trackRef.current;
        if (!el) return;
        el.scrollTo({left: idx * el.clientWidth, behavior: 'smooth'});
    };

    const Card = (it: AdvantageItem) => (
        <div
            className={clsx(
                'rounded-[24px] bg-white p-6 md:p-8',
                'ring-1 ring-[#DCE6FB] shadow-sm'
            )}
        >
            <div className="mb-5 h-16 w-16 md:h-20 md:w-20">
                <div className="relative h-full w-full">
                    <Image
                        src={it.image}
                        alt={it.alt ?? it.title}
                        fill
                        sizes="80px"
                        className="object-contain"
                    />
                </div>
            </div>

            <h3 className="text-xl md:text-2xl font-semibold leading-snug text-[#0A1DB7]">
                {it.title}
            </h3>
            <p className="mt-3 text-slate-600 md:text-base leading-relaxed">
                {it.text}
            </p>
        </div>
    );

    return (
        <div className={className}>
            <div
                ref={trackRef}
                className={clsx(
                    'md:hidden',
                    '-mx-4 px-4',
                    'flex snap-x snap-mandatory overflow-x-auto gap-4',
                    '[scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden'
                )}
            >
                {items.map((it, idx) => (
                    <div key={idx} className="snap-center shrink-0 basis-full">
                        {Card(it)}
                    </div>
                ))}
            </div>

            <div className="md:hidden mt-3 flex justify-center gap-2">
                {items.map((_, idx) => (
                    <button
                        key={idx}
                        aria-label={`Go to slide ${idx + 1}`}
                        onClick={() => scrollToIdx(idx)}
                        className={clsx(
                            'h-2 w-2 rounded-full transition',
                            idx === active ? 'bg-[#0A1DB7]' : 'bg-slate-300'
                        )}
                    />
                ))}
            </div>

            <div className="hidden grid-cols-1 gap-6 md:grid md:grid-cols-2">
                {items.map((it, idx) => (
                    <Card {...it} key={idx} />
                ))}
            </div>
        </div>
    );
}
