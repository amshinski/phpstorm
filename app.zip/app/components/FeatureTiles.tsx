'use client';

import clsx from 'clsx';

export type FeatureItem = { text: string };

type Props = {
    items: FeatureItem[];
    className?: string;
};

export default function FeatureTiles({ items, className }: Props) {
    return (
        <div
            className={clsx(
                'grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4',
                className
            )}
        >
            {items.map((item, idx) => {
                const n = idx + 1;

                const isBlue = n === 2;
                const isLightBlue = n === 8;

                const base =
                    'relative min-h-[220px] rounded-3xl p-6 ring-1 shadow-sm flex';
                const normal =
                    'bg-white ring-black/5';
                const blue =
                    'bg-gradient-to-br from-[#0A1DB7] to-[#2D6BFF] text-white ring-transparent';
                const lightBlue =
                    'bg-gradient-to-br from-[#DDF3FF] via-white to-white ring-black/5';

                return (
                    <div
                        key={idx}
                        className={clsx(
                            base,
                            isBlue ? blue : isLightBlue ? lightBlue : normal
                        )}
                    >
                        {/* number */}
                        <span
                            className={clsx(
                                'absolute right-5 top-4 text-xl font-semibold',
                                isBlue ? 'text-white/80' : 'text-slate-300'
                            )}
                        >
              {String(n).padStart(2, '0')}
            </span>

                        {/* text */}
                        <p
                            className={clsx(
                                'mt-6 text-lg leading-relaxed',
                                isBlue ? 'text-white/90' : 'text-slate-500'
                            )}
                        >
                            {item.text}
                        </p>
                    </div>
                );
            })}
        </div>
    );
}
