"use client";

import Image, {StaticImageData} from "next/image";
import Link from "next/link";
import {useState} from "react";
import clsx from "clsx";

export type ProductTile = {
    id: number;
    title: string;
    href: string;
    icon: string | StaticImageData;
};

export type InsuranceTabs = {
    savings: ProductTile[];      // Накопления
    investments: ProductTile[];  // Инвестиции
    protection: ProductTile[];   // Защита
};

type Props = {
    data: InsuranceTabs;
    className?: string;
};

export default function InsuranceSection({data, className}: Props) {
    const [tab, setTab] = useState<"savings" | "investments" | "protection">(
        "savings"
    );

    const items = data[tab] ?? [];

    /**
     * Desktop (md+): grid-cols-3.
     *   - items[0..2] -> row 1
     *   - items[3] -> row 2 col 1  (md:col-start-1)
     *   - items[4] -> row 2 col 3  (md:col-start-3)
     *
     * Mobile: grid-cols-2.
     *   - last tile spans both columns (col-span-2) to match the mock.
     */
    return (
        <section className={clsx("w-full", className)}>
            <h2 className="mb-5 text-4xl font-semibold tracking-tight text-[#1C2A52]">
                Страхование
            </h2>

            {/* Tabs */}
            <div className="mb-6 inline-flex rounded-full bg-[#F3F6FB] p-1">
                <TabButton active={tab === "savings"} onClick={() => setTab("savings")}>
                    Накопления
                </TabButton>
                <TabButton
                    active={tab === "investments"}
                    onClick={() => setTab("investments")}
                >
                    Инвестиции
                </TabButton>
                <TabButton
                    active={tab === "protection"}
                    onClick={() => setTab("protection")}
                >
                    Защита
                </TabButton>
            </div>

            {/* Grid */}
            <div className="grid grid-cols-2 gap-6 md:grid-cols-3">
                {items.map((tile, i) => {
                    const isLast = i === items.length - 1;

                    return (
                        <article
                            key={tile.id}
                            className={clsx(
                                "group relative overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-sm",
                                "min-h-[200px] md:min-h-[220px]",
                                // desktop centering for bottom row
                                i === 3 && "md:col-start-1",
                                i === 4 && "md:col-start-3",
                                // mobile: last card full width
                                isLast && "col-span-2 md:col-span-1"
                            )}
                        >
                            <Link href={tile.href} className="absolute inset-0" aria-label={tile.title} />

                            <div className="flex h-full flex-col p-6">
                                <h3 className="mr-20 text-2xl font-semibold leading-tight text-[#1C2A52]">
                                    {tile.title}
                                </h3>

                                <div className="mt-auto flex items-end justify-between">
                                    {/* small ↗ button */}
                                    <span
                                        aria-hidden
                                        className="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-[#F3F6FB] text-[#1C2A52]"
                                    >
                    ↗
                  </span>

                                    <div className="relative h-24 w-28 md:h-28 md:w-32">
                                        <Image
                                            src={tile.icon}
                                            alt=""
                                            fill
                                            sizes="(min-width: 768px) 128px, 112px"
                                            className="object-contain"
                                        />
                                    </div>
                                </div>
                            </div>
                        </article>
                    );
                })}
            </div>
        </section>
    );
}

function TabButton({
                       active,
                       onClick,
                       children,
                   }: {
    active: boolean;
    onClick: () => void;
    children: React.ReactNode;
}) {
    return (
        <button
            onClick={onClick}
            className={clsx(
                "rounded-full px-6 py-3 text-base font-semibold",
                active
                    ? "bg-white text-[#1C2A52] shadow-sm"
                    : "text-[#2E3E71]/70 hover:text-[#2E3E71]"
            )}
            type="button"
        >
            {children}
        </button>
    );
}
