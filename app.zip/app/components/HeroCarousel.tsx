'use client';

import Image, { StaticImageData } from 'next/image';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Link from 'next/link';
import clsx from 'clsx';

export type HeroSlide = {
    title: string;
    text: string;
    link: { href: string; label: string };
    image: string | StaticImageData;
    alt?: string;
};

type Props = {
    slides: HeroSlide[];
    /** Autoplay interval (ms). Default 3000 per your requirement. */
    autoPlayMs?: number;
    className?: string;
};

export default function HeroCarousel({ slides, autoPlayMs = 3000, className }: Props) {
    const [i, setI] = useState(0);
    const timer = useRef<NodeJS.Timeout | null>(null);
    const hovering = useRef(false);
    const touch = useRef<{ x: number; y: number } | null>(null);

    const len = slides.length;
    const go = useCallback((to: number) => setI((p) => (to + len) % len), [len]);
    const next = useCallback(() => go(i + 1), [i, go]);
    const prev = useCallback(() => go(i - 1), [i, go]);

    // autoplay (3s default)
    useEffect(() => {
        if (len <= 1) return;
        if (timer.current) clearTimeout(timer.current);
        if (!hovering.current) {
            timer.current = setTimeout(next, autoPlayMs);
        }
        return () => {
            if (timer.current) clearTimeout(timer.current);
        };
    }, [i, len, next, autoPlayMs]);

    const onMouseEnter = () => {
        hovering.current = true;
        if (timer.current) clearTimeout(timer.current);
    };
    const onMouseLeave = () => {
        hovering.current = false;
        timer.current = setTimeout(next, autoPlayMs);
    };

    // swipe on mobile
    const onTouchStart = (e: React.TouchEvent) => {
        const t = e.touches[0];
        touch.current = { x: t.clientX, y: t.clientY };
    };
    const onTouchEnd = (e: React.TouchEvent) => {
        if (!touch.current) return;
        const t = e.changedTouches[0];
        const dx = t.clientX - touch.current.x;
        const dy = t.clientY - touch.current.y;
        touch.current = null;
        if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 40) {
            dx < 0 ? next() : prev();
        }
    };

    const current = useMemo(() => slides[i], [i, slides]);

    return (
        <section
            className={clsx(
                'relative w-full overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-black/5',
                className
            )}
            onMouseEnter={onMouseEnter}
            onMouseLeave={onMouseLeave}
            onTouchStart={onTouchStart}
            onTouchEnd={onTouchEnd}
            aria-roledescription="carousel"
        >
            {/* Viewport */}
            <div className="relative">
                {/* Track */}
                <div
                    className="flex transition-transform duration-500 ease-out will-change-transform"
                    style={{ transform: `translateX(-${i * 100}%)` }}
                >
                    {slides.map((s, idx) => (
                        <article
                            key={idx}
                            className="relative w-full flex-none"
                            aria-roledescription="slide"
                        >
                            {/* Slide grid */}
                            <div className="grid min-h-[360px] grid-cols-1 items-stretch md:min-h-[520px] md:grid-cols-2">
                                {/* Left copy */}
                                <div className="flex flex-col justify-center px-6 py-10 md:px-12">
                                    <h2 className="text-4xl/tight font-extrabold tracking-tight text-[#0A1DB7] md:text-6xl">
                                        <Link href={s.link.href}>
                                            {s.title}
                                        </Link>
                                    </h2>

                                    <p className="mt-6 max-w-[48ch] text-lg text-slate-500 md:text-2xl whitespace-pre-line">
                                        {s.text}
                                    </p>
                                </div>

                                {/* Right visual, image locked to bottom */}
                                <div className="relative flex items-end">
                                    {/* soft radial backdrop */}
                                    <div className="pointer-events-none absolute inset-0 opacity-70 [background:radial-gradient(80%_60%_at_65%_50%,rgba(13,180,120,0.18),transparent_60%)]" />
                                    {/* decorative frame */}
                                    <div className="pointer-events-none absolute right-10 top-8 hidden h-[72%] w-[72%] -rotate-2 rounded-2xl border-[10px] border-emerald-500/90 md:block" />

                                    <div className="relative h-full w-full">
                                        <Image
                                            src={s.image}
                                            alt={s.alt ?? s.title}
                                            fill
                                            sizes="(min-width: 768px) 50vw, 100vw"
                                            priority={idx === 0}
                                            className="object-contain object-bottom"
                                        />
                                    </div>
                                </div>
                            </div>
                        </article>
                    ))}
                </div>
            </div>

            {/* Dots pinned to bottom-left */}
            {len > 1 && (
                <div className="pointer-events-auto absolute bottom-4 left-6 flex items-center gap-2">
                    {slides.map((_, idx) => (
                        <button
                            key={idx}
                            aria-label={`Go to slide ${idx + 1}`}
                            onClick={() => go(idx)}
                            className={clsx(
                                'size-2 rounded-full transition',
                                idx === i ? 'bg-[#0A1DB7]' : 'bg-slate-200'
                            )}
                        />
                    ))}
                </div>
            )}
        </section>
    );
}
