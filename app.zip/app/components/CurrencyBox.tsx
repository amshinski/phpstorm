"use client";

export type CurrencyItem = {
    code: "USD" | "EUR" | string;
    value: number;
    trend: "up" | "down" | "flat";
};

type Props = { items: CurrencyItem[] };

export default function CurrencyBox({ items }: Props) {
    return (
        <div className="rounded-3xl bg-[#0E2347] p-6 text-white shadow-md">
            <div className="text-xs/5 text-white/60 mb-4">05.08.2025</div>
            <ul className="space-y-4">
                {items.map((c) => (
                    <li key={c.code} className="flex items-center justify-between">
                        <div className="text-lg font-semibold tracking-wide">{c.code}</div>
                        <div className="flex items-center gap-3">
                            <span className="text-white/80">{c.value.toFixed(2)}</span>
                            <TrendArrow trend={c.trend} />
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
}

function TrendArrow({ trend }: { trend: "up" | "down" | "flat" }) {
    if (trend === "up") {
        return (
            <span
                className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-green-600/20 text-green-400"
                title="Рост"
            >
        ↑
      </span>
        );
    }
    if (trend === "down") {
        return (
            <span
                className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-rose-600/20 text-rose-400"
                title="Падение"
            >
        ↓
      </span>
        );
    }
    return (
        <span
            className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-slate-500/20 text-slate-300"
            title="Без изменений"
        >
      →
    </span>
    );
}
