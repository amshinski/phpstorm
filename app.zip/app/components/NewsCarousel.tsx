"use client";

import Image, { StaticImageData } from "next/image";
import Link from "next/link";
import { useMemo, useState } from "react";
import clsx from "clsx";

export type NewsItem = {
    id: number;
    date: string;
    title: string;
    image?: string | StaticImageData;
    href: string;
};

type Props = {
    items: NewsItem[];
    className?: string;
};

export default function NewsCarousel({ items, className }: Props) {
    const [index, setIndex] = useState(0);

    const next = () => setIndex((i) => (i + 1) % items.length);
    const prev = () => setIndex((i) => (i - 1 + items.length) % items.length);

    const visible = useMemo(
        () => [items[index], items[(index + 1) % items.length], items[(index + 2) % items.length]],
        [index, items]
    );

    return (
        <div className={clsx("relative", className)}>
            {/* Toggle row (optional) */}
            <div className="mb-5">
                <div className="inline-flex rounded-full bg-slate-100 p-1">
                    <button
                        className="rounded-full px-5 py-2 text-sm font-medium bg-white shadow-sm"
                        aria-current="page"
                    >
                        Новости
                    </button>
                    <button
                        className="rounded-full px-5 py-2 text-sm font-medium text-slate-500 hover:text-slate-700"
                        disabled
                        title="В демо активна только вкладка «Новости»"
                    >
                        Статьи
                    </button>
                </div>
            </div>

            {/* 3 cards in a row — first one is wider and shows image */}
            <div className="flex gap-6">
                {visible.map((item, i) =>
                    i === 0 ? (
                        <FeaturedCard key={item.id} item={item} />
                    ) : (
                        <CompactCard key={item.id} item={item} />
                    )
                )}
            </div>

            {/* Arrows */}
            <div className="mt-6 flex gap-3">
                <button
                    onClick={prev}
                    aria-label="Предыдущие новости"
                    className="rounded-2xl border border-slate-200 bg-white/80 px-3 py-2 shadow-sm backdrop-blur hover:bg-white"
                >
                    ‹
                </button>
                <button
                    onClick={next}
                    aria-label="Следующие новости"
                    className="rounded-2xl border border-slate-200 bg-white/80 px-3 py-2 shadow-sm backdrop-blur hover:bg-white"
                >
                    ›
                </button>
            </div>
        </div>
    );
}

function FeaturedCard({ item }: { item: NewsItem }) {
    return (
        <article className="group relative flex basis-[52%] flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
            <div className="px-6 pt-5 text-sm text-slate-500">{item.date}</div>

            <Link href={item.href} className="px-6 pb-4 pt-1">
                <h3 className="line-clamp-3 text-xl font-semibold leading-snug text-slate-900 group-hover:underline">
                    {item.title}
                </h3>
            </Link>

            {item.image && (
                <div className="relative mt-2 aspect-[16/9] w-full">
                    <Image
                        src={item.image}
                        alt=""
                        fill
                        className="object-cover"
                        sizes="(min-width: 1280px) 640px, 100vw"
                        priority
                    />
                </div>
            )}

            <div className="flex items-center justify-end p-4">
                <Link
                    href={item.href}
                    className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-slate-700 transition group-hover:bg-slate-200"
                    aria-label="Перейти"
                >
                    ↗
                </Link>
            </div>
        </article>
    );
}

function CompactCard({ item }: { item: NewsItem }) {
    return (
        <article className="group relative flex basis-[24%] flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
            <div className="px-6 pt-5 text-sm text-slate-500">{item.date}</div>
            <Link href={item.href} className="px-6 pb-6 pt-1">
                <h3 className="line-clamp-6 text-lg font-semibold leading-snug text-slate-900 group-hover:underline">
                    {item.title}
                </h3>
            </Link>
            <div className="mt-auto flex items-center justify-end p-4">
                <Link
                    href={item.href}
                    className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-slate-700 transition group-hover:bg-slate-200"
                    aria-label="Перейти"
                >
                    ↗
                </Link>
            </div>
        </article>
    );
}
