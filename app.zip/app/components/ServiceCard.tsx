'use client';

import Image, { StaticImageData } from 'next/image';
import Link from 'next/link';
import clsx from 'clsx';

export type ServiceCardItem = {
    title: string;
    text: string;
    image: string | StaticImageData;
    link: string;
    alt?: string;
};

type Props = {
    item: ServiceCardItem;
    className?: string;
};

export default function ServiceCard({ item, className }: Props) {
    return (
        <Link
            href={item.link}
            className={clsx(
                'group relative block overflow-hidden rounded-3xl bg-white p-6 ring-1 ring-black/5 shadow-sm',
                'transition hover:shadow-md',
                className
            )}
        >
            {/* text */}
            <div className="relative z-10 pr-24">
                <h3 className="text-2xl font-semibold text-slate-900">
                    {item.title}
                </h3>
                <p className="mt-2 text-slate-500">{item.text}</p>
            </div>

            {/* arrow chip bottom-left */}
            <div className="absolute bottom-4 left-4 rounded-xl bg-slate-100 p-2 text-slate-500 transition group-hover:bg-slate-200">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden>
                    <path d="M9 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
            </div>

            {/* image on the right */}
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-end pr-4">
                <div className="relative h-28 w-28 md:h-36 md:w-36">
                    <Image
                        src={item.image}
                        alt={item.alt ?? item.title}
                        fill
                        className="object-contain object-bottom"
                        sizes="(min-width: 768px) 144px, 112px"
                        priority={false}
                    />
                </div>
            </div>
        </Link>
    );
}
