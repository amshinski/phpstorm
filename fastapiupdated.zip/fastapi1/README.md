##### Поднимаем проект локально
1. Копируем файлы докера и создаем .env:
   ```bash
   cp -n .env.example .env

   cp ./docker/develop/docker-compose.yml .
   ```
2. Собираем контейнеры:
    ```bash
    docker-compose build
    ```
3. Запускаем контейнеры:
    ```bash
    docker-compose up -d

##### Запускаем проект локально, делаем миграции
1. Создаем virtual environment
   ```bash
   py -m venv venv
2. Активируем virtual environment
   ```bash
   source venv/Scripts/activate
3. Устанавливаем пакеты
   ```bash
   pip install -r requirements.txt
4. Обновляем pip
   ```bash
   py -m pip install --upgrade pip
5. Секреты можно сгенерить командой и вставить в .env
   ```bash
   py -m app.cli generate-secret
6. Заполнить .env
7. Делаем миграции
   ```bash
   alembic upgrade head
8. Запускаем сервер
   ```bash
   fastapi dev main.py
9. В браузере открыть 127.0.0.1:8000/docs


\+ В PyCharm открыть requirements.txt и установить пакеты, если он ругается


##### Кастомные команды
1. Добавить фичу в app/features
   ```bash
   py -m app.cli create-feature feature-name
2. Добавить фичу в app/admin/features
   ```bash
   py -m app.cli create-admin-feature feature-name
3. Создать бойлерплейт команды
   ```bash
   py -m app.cli create-command command-name
4. Дроп БД
   ```bash
   py -m app.cli db-reset
5. Сид (2 юзера)
   ```bash
   py -m app.cli seed
