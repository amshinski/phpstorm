// ** Fake user data and data type
// =============== Fake Data ============================
export const users = [
  {
    id: 1,
    name: 'John Doe',
    password: 'admin',
    email: 'admin@vuexy.com',
    image: '/images/avatars/1.png'
  }
]
