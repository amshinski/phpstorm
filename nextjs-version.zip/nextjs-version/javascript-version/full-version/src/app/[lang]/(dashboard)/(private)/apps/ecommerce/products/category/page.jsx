// Component Imports
import ProductCategoryTable from '@views/apps/ecommerce/products/category/ProductCategoryTable'

const eCommerceProductsCategory = () => {
  return <ProductCategoryTable />
}

export default eCommerceProductsCategory
