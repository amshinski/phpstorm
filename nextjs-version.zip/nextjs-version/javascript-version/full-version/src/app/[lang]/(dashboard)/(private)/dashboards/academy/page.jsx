// Component Imports
import AcademyDashboard from '../../apps/academy/dashboard/page'

const DashboardAcademy = async () => {
  return <AcademyDashboard />
}

export default DashboardAcademy
