const spacing = {
  spacing: factor => `${0.25 * factor}rem`
}

export default spacing
